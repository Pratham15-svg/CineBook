# CineBook Phase 2 in Plain English

For anyone on the team who needs to explain the Phase 2 files without reading all the code. Use it next to the actual files.

---

## The big picture

Phase 1 built an empty building: tables, rules and procedures. Phase 2 did three things:

1. **Added the missing pieces** (`05_indexes_views.sql`): speed-ups, a few extra safety rules, and ready-made questions (views) the app will ask.
2. **Moved furniture in** (`generate_seed_data.py`): about 10,000 rows of believable fake data, so the system looks used.
3. **Tried to break everything on purpose** (`w3_tests.sql`): 38 tests that prove the database refuses bad data and accepts good data.

---

## File 1: `05_indexes_views.sql`

**Indexes** are like the index at the back of a book. Without one, the database reads every page to find a movie's shows. With one, it jumps straight to the right pages. PostgreSQL makes an index for primary keys automatically but not for foreign keys, so we added them.

**A partial index** is an index that only lists some rows. Our "held bookings" index lists only bookings that are currently on hold, which are very few, so it is tiny and fast.

**The future-show rule** stops anyone holding seats for a movie that already started, like a cinema refusing to sell a ticket for a film halfway through.

**`sp_expire_holds`** is a cleaner. A hold lasts 10 minutes. This procedure finds holds that ran out and marks them EXPIRED, which automatically frees the seats. Even before the cleaner runs, the seat map already shows an expired hold as free, so customers are never stuck.

**`sp_record_failed_payment`** writes down that a payment failed. If a payment fails, the booking attempt is cancelled and undone, then the failure is written separately so it is not undone too. The customer can try again until the hold ends.

**Views** are saved questions. Instead of the backend writing a long query each time, it says "show me `v_ticket`". The ones we made:

| Name | Answers the question |
|---|---|
| `v_show_search` | Which shows match this city / language / price, and how many seats are free? |
| `fn_seat_map(show)` | For this show, which seats are free, held or booked? |
| `v_ticket` | Show me this booking's ticket (fast: no extra table lookups) |
| `v_revenue_venue_month` | How much money did each venue make each month? |
| `v_show_occupancy` | What percent of each show's seats are sold? |
| `v_top_movies_city` | Top 3 movies in each city |
| `v_peak_hours` | At what hour of the day do people book most? |

---

## File 2: `generate_seed_data.py`

Think of it as a film-set builder. It does the work in this order:

1. **Builds the world:** users (1 admin, 10 managers, 40 customers), 5 cities, 10 cinemas, 25 screens, about 2,000 seats, 20 movies, 300 shows, and prices.
2. **Makes customers book tickets, using our own procedures**, the same way the real app will. So every rule (6 seats maximum, coupon limits, exact prices) is applied to every fake booking. If the script finishes, the procedures worked 988 times in a row.
3. **Creates different stories on purpose:** people who paid, people whose first payment failed and then succeeded, people who cancelled (some get a full refund, some half), people who abandoned a hold, and a few holds still waiting.
4. **Back-dates the history.** The procedures stamp everything with "now", so all bookings would look like they happened this minute. The script rewrites the times to spread them over about a month, with more bookings in the evening, so the dashboards show a real pattern.

Details that are easy to forget:
- It refuses to run on a database that already has data, unless you add `--reset`.
- It always produces the same shape of data (fixed random seed 42).
- Every user has the password `Password@123` (stored safely as a hash).
- The 8 "on hold" bookings run out 10 minutes after seeding, on purpose, because that is how holds work.

---

## File 3: `w3_tests.sql`

Each test is one attempt to do something wrong (or right), with the error we expect:

- **"Must fail" tests** try bad things: seven seats, a negative price, an overlapping show, buying the same seat twice. The test passes when the database says no, with the right error code.
- **"Must succeed" tests** try allowed things: back-to-back shows, re-booking a seat after cancelling, a refund of exactly half. These prove the rules are not too strict.

The error codes in short:

| Code | In plain words |
|---|---|
| `23505` | "That already exists" (duplicate seat booking, duplicate e-mail) |
| `23503` | "That refers to something that doesn't exist or doesn't match" |
| `23514` | "That value breaks a simple rule" (price 0, bad role) |
| `23P01` | "That clashes with another row" (overlapping shows) |
| `P0001` | "One of our own custom rules said no" (too late to cancel, coupon expired) |

Two safety features of the script: it **rolls back** at the end (nothing is saved, so you can run it as often as you like), and it **builds its own test data** (so it never clashes with the seeded data).

To make sure the tests are honest, we deleted the double-booking rule in a copy of the database and the matching test went red. So a green result means something.

---

## Cheat sheet: what to run

| I want to... | Command |
|---|---|
| Start the database | `docker compose up -d db` |
| Fill it with data | `python db/seed/generate_seed_data.py` |
| Start over | `python db/seed/generate_seed_data.py --reset` |
| Prove the rules work | `docker exec -i cinebook-db psql -U postgres -d cinebook < db/tests/w3_tests.sql` |
| Look inside the database | `docker exec -it cinebook-db psql -U postgres -d cinebook` |
