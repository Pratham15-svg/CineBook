# CineBook: Viva Preparation Notes, Phase 2

Covers the work added after Phase 1: Docker setup, `05_indexes_views.sql`, the seed script and the W3 test log.
For every part: **what we built, why, the alternative we rejected, and how it works.** Read `CineBook_Viva_Prep_Notes` (Phase 1) for the schema, triggers and procedures.

---

## Part A: Docker setup (Step 0)

**What:** `docker-compose.yml` starts PostgreSQL in a container and mounts the `db/` folder into `/docker-entrypoint-initdb.d`. On the first start with an empty data volume, Postgres runs every `.sql` file in that folder in alphabetical order: `00` to `05`. Files in sub-folders (`db/tests`, `db/seed`) are NOT run automatically.

**Why numbered files:** alphabetical order is the run order, so each file can rely on the previous one (tables before constraints, constraints before triggers).

**Why Docker:** every team member gets the same database version and setup with one command, so "it works on my machine" problems disappear. It also matches the plan to run the whole system with Docker Compose in Phase 5.

**Be ready to say:**
- *"The init scripts only run once."* If the data volume already exists, Postgres skips them. A new file such as `05` must then be run by hand, or the volume deleted with `docker compose down -v` (this wipes the data).
- *Version:* the report says PostgreSQL 16, the compose file uses `postgres:latest`. State the version you actually ran (`SELECT version();`).

---

## Part B: `05_indexes_views.sql`

This file came from reading the Phase 1 SQL and listing what was missing. Each item below is a problem and its fix.

### B1. Indexes
- **Problem:** PostgreSQL does NOT create an index for a foreign key automatically (it only does so for primary keys and UNIQUE). Without one, every "all shows for this movie" or "all bookings for this show" scans the whole table.
- **Fix:** indexes on `MOVIE_SHOW(movie_id)`, `MOVIE_SHOW(start_time)`, `VENUE(city_id)`, `VENUE(manager_id)`, `BOOKING(show_id)`, `BOOKING(coupon_id)`, `PAYMENT(booking_id)`, `BOOKING_AUDIT(booking_id)`.
- **Partial indexes:** `idx_booking_held_expiry ON BOOKING(hold_expires_at) WHERE status='HELD'` only indexes the few rows that are currently held, so it stays tiny and the expiry sweep is fast. The coupon index skips NULL (most bookings have no coupon). Partial index = index with a WHERE condition.
- **Mistake fixed:** a comment in `04_procedures.sql` said the sweep was fast "because of the status index", but no such index existed. Now it does.

### B2. Case-insensitive unique e-mail
- `UNIQUE INDEX ON APP_USER (lower(email))`. A plain `UNIQUE (email)` treats `Ravi@x.com` and `ravi@x.com` as different people. An index on an *expression* fixes this. Tested in T31.

### B3. "Show must be in the future" trigger
- **Problem:** `sp_create_booking` would happily hold seats for a show that already started.
- **Why a trigger (BEFORE INSERT on BOOKING):** it covers every way of inserting a booking, not just one procedure.
- **The bypass:** the seed needs back-dated history, so the trigger skips the check when the session setting `cinebook.allow_past_booking` is `'on'`. The seed sets it with `set_config(..., true)` where `true` means "only for this transaction". The app never sets it. Be ready to explain this is a deliberate, documented escape hatch for test data, and that it is invisible to normal users.

### B4. `sp_expire_holds`
- **Problem:** a HELD booking only became EXPIRED when someone next called `sp_create_booking`. Until then its seats looked taken.
- **Fix (two layers):** (1) the procedure `sp_expire_holds` can be called on a schedule or before listing bookings; (2) the read queries treat `HELD` with `hold_expires_at < now()` as free anyway, so the user never sees a stale lock. The expire step is an UPDATE of status, so the existing triggers free the seats and write the audit row automatically.

### B5. `sp_record_failed_payment` (rule R7)
- **Problem:** `PAYMENT.status` allows FAILED, and R7 says a retry is a new row, but nothing ever wrote a FAILED row.
- **Why a separate procedure and transaction:** when a payment fails, the backend must ROLLBACK the confirm attempt (so no half-confirmed booking), and then record the failure separately. If the failure were recorded in the same transaction, the rollback would erase it. The booking stays HELD so the customer can retry within 10 minutes.

### B6. Read queries (views and a function)
| Object | For | Technique to name |
|---|---|---|
| `v_show_search` | show search | joins + `LEFT JOIN LATERAL` subqueries for price range, seat totals, seats taken |
| `fn_seat_map(show_id)` | seat map | function with a parameter; LEFT JOINs from SEAT to active bookings; `CASE` for AVAILABLE/HELD/BOOKED |
| `v_ticket` | ticket page, my bookings | reads ONLY BOOKING and BOOKING_SEAT; `jsonb_agg` for seat details; `effective_status` |
| `v_revenue_venue_month` | admin dashboard | `GROUP BY`, `date_trunc('month', ...)`, India time |
| `v_show_occupancy` | manager/admin | `COUNT(*) FILTER (WHERE ...)` for sold vs held |
| `v_top_movies_city` | admin dashboard | CTE + `ROW_NUMBER() OVER (PARTITION BY city ...)` |
| `v_peak_hours` | admin dashboard | `GROUP BY EXTRACT(HOUR ...)` |

**Why `fn_seat_map` is a function and not a view:** it needs a parameter (which show). A view has no parameters; a function does.
**Why LATERAL:** each subquery needs the current row's `show_id`. A normal join can't reference the row to its left; LATERAL can.
**Why ROW_NUMBER and not RANK:** RANK gives ties the same number, which could return 4 movies for "top 3". ROW_NUMBER with a tie-break (tickets, then revenue, then title) always returns exactly 3.
**Why `v_ticket` matters:** it is the "fast read path" promised in the mid-sem report. Because BOOKING stores a snapshot of movie/venue/screen/show time, the ticket needs no joins to those tables. This is what the EXPLAIN ANALYZE comparison in Phase 5 will measure.
**Why `effective_status`:** a hold that ran out but has not been swept yet should display as EXPIRED, not HELD.

---

## Part C: The seed script

**What:** `generate_seed_data.py` fills an empty database with about 10,000 rows: 51 users, 5 cities, 10 venues, 25 screens, 1,970 seats, 20 movies, 300 shows, 900 show prices, 5 coupons, and 988 bookings with their seats, payments and audit rows.

### C1. Why bookings go through the stored procedures
- **Alternative rejected:** inserting BOOKING and BOOKING_SEAT rows directly with Python. That would skip every trigger and rule, so the data could be inconsistent and nothing would be tested.
- **Why procedures:** every seeded booking obeys the same rules as a real one: price snapshots, coupon limits, price_paid adding up exactly, audit rows, seat release on cancel. If the seed finishes without errors, that is itself evidence the procedures work on 988 bookings.

### C2. Insert order
Users first (managers must exist before venues because of the manager trigger), then cities, venues, screens, seats, movies, shows, show prices, coupons. This is the foreign-key dependency order.

### C3. How shows avoid overlapping (R3)
Each screen has four daily time slots (10:00, 13:30, 17:00, 20:30), 3.5 hours apart. The longest movie is 160 minutes plus a 15-minute cleaning gap, which is under 3.5 hours, so two shows in different slots can never overlap. The script never uses the same (day, slot) twice on a screen. The exclusion constraint is still the real guard; the script just avoids triggering it.

### C4. Every show needs a price for every seat category on its screen
Otherwise `sp_create_booking` raises "No price set for category". The script inserts a price row per category per show.

### C5. Back-dating
- **Problem:** the procedures stamp `now()` on everything, so all 988 bookings would be "today" and the monthly revenue and peak-hours dashboards would look empty.
- **Fix:** after the procedures run, the script UPDATEs `booked_at`, `PAYMENT.paid_at` and `BOOKING_AUDIT.changed_at`. This is safe because no trigger fires on those columns (the triggers watch `status` and `total_amount` only).
- **Realistic shape:** booking time uses weights per hour (quiet at night, lunch bump, strong evening peak) and popular movies get more bookings (weight 1/rank^0.8), so "peak hours" and "top 3 movies" show a real pattern, not noise.
- **Honest caveat:** this history is synthetic. Say so if asked; it exists to test the queries, not to claim real usage.

### C6. Other design choices
- **Fixed random seed (42):** same shape of data every time, so results are reproducible.
- **Scenarios covered:** confirmed bookings on past and future shows, failed-then-retried payments (R7), cancellations (both refund tiers), expired holds, and a few live holds.
- **Seats picked as neighbours** in one row when possible, like a real customer.
- **Passwords:** one bcrypt hash computed once and reused, with a known demo password. Fine for test data; a real system gives every user a unique salt.
- **Safety:** the script refuses to run on a database that already has data unless `--reset` is given.

---

## Part D: The W3 test log

**What:** `w3_tests.sql`, 38 tests, each with an expected SQLSTATE. Full table in `W3_TEST_REPORT_SECTION.md`.

**Why it runs in one transaction with ROLLBACK:** it leaves no data behind, so it can be run any time, including on the seeded database before a demo. It builds its own test data (names starting "W3 ") so it never collides with the seed.

**Why compare error codes (SQLSTATE) and not just "an error happened":** a test that only checks "something failed" can pass for the wrong reason (for example, a typo in the SQL). Checking the exact code and which constraint fired proves the intended rule did the rejecting.

**Why include "must succeed" tests (T22, T23, T20, ...):** a database that rejects everything would also pass the "must fail" tests. The positive tests prove the rules are not too strict.

**How we know the tests can fail:** dropping `uq_active_seat_per_show` in a scratch copy made T10 fail. Reproduction commands are in `W3_TEST_REPORT_SECTION.md`.

**Two findings to mention proudly (they show you read the results, not just ran them):**
1. T02: an empty booking is caught by the CHECK `total_amount > 0`, not by the seat-count trigger, because that trigger only fires when a seat row is inserted.
2. T13: paying after the hold expired is rejected; the EXPIRED status change inside the procedure is rolled back by the backend, and the sweep expires the booking later.

---

## Part E: Quick-fire Q&A bank

**Q: Why not just use `seed.sql` with INSERT statements?**
A: Generated data is larger and more realistic (Faker), is reproducible, and goes through the real procedures so every rule is exercised. A fixed INSERT file would need hand-written bookings and would bypass the booking logic.

**Q: You turned off the future-show rule for the seed. Isn't that cheating?**
A: It is a documented bypass, scoped to a single transaction, and only the seed script sets it. Without it we could not create past bookings to fill the revenue and peak-hour dashboards. The rule is still tested with it on (T04).

**Q: Why does the seed UPDATE timestamps? Doesn't that break the audit log?**
A: The audit rows are updated to match (`changed_at`), and we checked that no audit row is earlier than its booking. No trigger fires on those columns, so nothing else changes.

**Q: What does `FOR UPDATE` on the coupon row do?** (from `sp_create_booking`)
A: It locks that row until the transaction ends, so two people using the last remaining coupon use cannot both succeed. The second waits, then sees the limit reached (T08 shows the rejection).

**Q: What happens if two users pick the same seat at the same moment?**
A: The partial unique index allows only one active row for (show, seat). The second insert fails with 23505 and the backend shows "seat just taken" (T10, T37).

**Q: How do you stop a screen from having two shows at once?**
A: An EXCLUDE constraint using a time range (`tstzrange`) and the `&&` overlap operator, which needs the `btree_gist` extension. The range is half-open `[)` so back-to-back shows are allowed (T21, T23).

**Q: Why does the hold expire only when someone calls a procedure? Isn't that sloppy?**
A: Postgres has no built-in timer for rows. So the read queries treat an expired hold as free immediately, and `sp_expire_holds` does the permanent cleanup. The user never sees a stale lock either way.

**Q: Why does the backend call one procedure per transaction?**
A: `SET CONSTRAINTS ... IMMEDIATE` inside the procedures lasts until the transaction ends. Chaining procedures would make later inserts check constraints immediately instead of at commit.

**Q: What are the weaknesses of your design?** (be honest, examiners like this)
A: (1) The manager-role rule is checked only when a venue is created or its manager changes, not if a user's role is changed later. (2) Coupons have only a global usage limit, no per-user limit. (3) The audit log doesn't record who made the change. (4) Holds are freed lazily. (5) The seed data is synthetic. All are acceptable for the stated scope and documented.

**Q: Which PostgreSQL version did you use, and why does it matter?**
A: Say the version from `SELECT version();`. EXCLUDE constraints with range types, deferred constraint triggers and partial indexes are the Postgres features the design depends on; MySQL does not offer them natively.
