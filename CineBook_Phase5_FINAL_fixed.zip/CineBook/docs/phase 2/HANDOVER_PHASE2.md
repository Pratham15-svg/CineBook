# CineBook: Phase 2 Handover (seed data + database testing)

**Prepared 1 November 2026.** Phase 2 is done and verified: the database has 10,049 rows and all 38 constraint tests pass. This file is what Phase 3 (backend) builds on. It follows the same idea as Pratham's Phase 1 handover.

Phase 1 handover (files `00` to `04`) still applies. Everything here sits on top of it.

---

## 1. What is new in the repo

| File | What it is |
|---|---|
| `db/05_indexes_views.sql` | Extra indexes, future-show rule, `sp_expire_holds`, `sp_record_failed_payment`, `fn_seat_map`, and 6 read views for the app and dashboards |
| `db/seed/generate_seed_data.py` | Fills the database with fake data (about 10,000 rows) |
| `db/seed/requirements.txt` | Python packages the seed script needs |
| `db/tests/smoke_test.sql` | Quick end-to-end check (hold, pay, cancel). Needs an EMPTY database |
| `db/tests/step1_test.sql` | Checks everything in `05`. Needs an EMPTY database |
| `db/tests/w3_tests.sql` | The W3 constraint test log (38 tests). Works on empty or seeded database |
| `docker-compose.yml` | Starts PostgreSQL and auto-runs the SQL files in `db/` on first start |

---

## 2. Set up from scratch

```
docker compose up -d db
docker exec -it cinebook-db psql -U postgres -d cinebook -c "\dv"
```
The second command should list 6 views. If it lists none, `05` did not run (Docker only auto-runs the SQL files the first time the data volume is created). Run it by hand:
```
docker exec -i cinebook-db psql -U postgres -d cinebook < db/05_indexes_views.sql
```
(On Windows cmd use backslashes: `db\05_indexes_views.sql`.)

Seed the data:
```
pip install -r db/seed/requirements.txt
python db/seed/generate_seed_data.py          # database must be empty
python db/seed/generate_seed_data.py --reset  # wipe everything, then reseed
```

Run the W3 test log and keep the output for the report:
```
docker exec -i cinebook-db psql -U postgres -d cinebook < db/tests/w3_tests.sql > docs/w3_test_log.txt
```

---

## 3. What is in the database now

| Table | Rows | | Table | Rows |
|---|---|---|---|---|
| APP_USER | 51 | | COUPON | 5 |
| CITY | 5 | | BOOKING | 988 |
| VENUE | 10 | | BOOKING_SEAT | 2,733 |
| SCREEN | 25 | | PAYMENT | 1,014 |
| SEAT | 1,970 | | BOOKING_AUDIT | 2,028 |
| MOVIE | 20 | | SHOW_PRICE | 900 |
| MOVIE_SHOW | 300 | | **Total** | **10,049** |

Bookings: 900 CONFIRMED, 60 CANCELLED, 20 EXPIRED, 8 HELD. Payments: 900 SUCCESS, 60 REFUNDED, 54 FAILED. 200 bookings used a coupon.

The seed uses a fixed random seed (42), so reseeding gives the same shape of data. Dates are relative to "today", so exact timestamps differ each run.

**Demo logins** (same password for all): `admin@cinebook.test`, `manager1` to `manager10`, `customer1` to `customer40` (all `@cinebook.test`). Password: `Password@123`. Passwords are bcrypt hashes (`$2b$10$...`), so the backend's login check works with the normal `bcrypt` package.

**Coupons for testing:** `WELCOME10` (10% off), `FLAT50` (50 off), `FESTIVAL15` (15%, limit 100), `BIGSAVER` (25%, only 5 uses), `EXPIRED20` (expired, for the W3 test).

---

## 4. Notes for Phase 3 (backend)

### 4.1 Never rebuild the booking logic in Node. Call the procedures

| Action | SQL | Returns |
|---|---|---|
| Hold seats | `CALL sp_create_booking($1::bigint, $2::bigint, $3::text[], $4::text, NULL)` | one row, column `p_booking_id` |
| Pay | `CALL sp_confirm_booking($1::bigint, $2::text, NULL)` | `p_payment_id` |
| Cancel | `CALL sp_cancel_booking($1::bigint, NULL)` | `p_refund_amount` |
| Record failed payment | `CALL sp_record_failed_payment($1::bigint, $2::text, NULL)` | `p_payment_id` |
| Expire old holds | `CALL sp_expire_holds(NULL)` | `p_expired_count` |

The trailing `NULL` is the INOUT placeholder. Pass the seat list as a normal JavaScript array. The explicit casts are a precaution; the seed script calls the same procedures from Python and works, but these exact Node calls are not tested yet, so check them first in Phase 3.

### 4.2 Transaction rules
- **One procedure per transaction.** `sp_create_booking` and `sp_confirm_booking` run `SET CONSTRAINTS ... IMMEDIATE`, which lasts until the transaction ends. If you chain several procedures in one transaction, later inserts are checked immediately instead of at commit.
- **Payment failure flow:** ROLLBACK the transaction that tried `sp_confirm_booking`, then in a NEW transaction call `sp_record_failed_payment`. The booking stays HELD so the customer can retry until the 10-minute hold ends (rule R7).
- A booking that is paid after its hold expires is rejected with `P0001`. Treat it as "hold expired, please book again".

### 4.3 Translate database errors into clean HTTP responses
The `pg` error object has `err.code` (SQLSTATE) and `err.constraint`.

| SQLSTATE | Meaning here | Suggested response |
|---|---|---|
| `23505` + `uq_active_seat_per_show` | seat just taken by someone else | 409 "seat no longer available" |
| `23505` + `uq_user_email_lower` | e-mail already registered | 409 |
| `23P01` | show overlaps another show on that screen | 409 "screen busy at that time" |
| `23514` | a CHECK failed (bad price, bad value) | 400 |
| `23503` | bad reference (unknown show, seat on wrong screen) | 400 |
| `P0001` | our own rule in a trigger or procedure (coupon invalid, 7 seats, too late to cancel, hold expired) | 400/409 with `err.message` |

Validate in the backend first where cheap (duplicate seat numbers in one request, 1 to 6 seats), but never rely on it. The database is the final guard.

### 4.4 Read queries already written (in `05`)

| Endpoint | Use |
|---|---|
| `POST /shows/search` | `SELECT * FROM v_show_search WHERE city_id=$1 AND start_time > now() ...` (also has `language`, `min_price`, `available_seats`) |
| `GET /shows/:id/seats` | `SELECT * FROM fn_seat_map($1)` returns AVAILABLE / HELD / BOOKED per seat; expired holds already show as AVAILABLE |
| `GET /bookings/:id`, `GET /me/bookings` | `SELECT * FROM v_ticket WHERE booking_id=$1` / `WHERE user_id=$1 ORDER BY booked_at DESC`. Uses only BOOKING and BOOKING_SEAT. Use `effective_status` for display |
| Admin revenue | `v_revenue_venue_month` (managers filter by `manager_id`) |
| Occupancy | `v_show_occupancy` (managers filter by `manager_id`) |
| Top 3 movies per city | `v_top_movies_city` |
| Peak hours | `v_peak_hours` |

Months and hours in the views use India time (`Asia/Kolkata`).

---

## 5. Things to know (decisions and limitations)

1. **The 8 HELD bookings lapse 10 minutes after seeding.** They have a real 10-minute hold. Seeding a long fake hold would break rule R5. Create a fresh hold through the API when demoing.
2. **Past-show bookings use a bypass.** The "show must be in the future" trigger blocks bookings for started shows. The seed switches it off per transaction with `cinebook.allow_past_booking = 'on'` to build history. The app never sets this.
3. **Seed timestamps are back-dated by design.** The procedures stamp `now()`, so the seed rewrites `booked_at`, `paid_at` and the audit times afterwards. No trigger fires on those columns, so history stays consistent (checked: no audit row is earlier than its booking).
4. **`smoke_test.sql` and `step1_test.sql` need an empty database.** They insert a city called Hyderabad, which the seed also creates. Run them on a fresh database or before seeding. `w3_tests.sql` is safe on both.
5. **Manager rule is one-sided.** The trigger checks the role when a venue is created or its manager changes. Changing a user's role later is not caught. Acceptable for this scope; mention it in the report.
6. **Coupons have no per-user limit**, only a global `max_uses` (counted over HELD and CONFIRMED bookings). **Audit rows have no "changed by".** Both fine for the stated rules.
7. **Docker image:** `docker-compose.yml` uses `postgres:latest`, but the report says PostgreSQL 16. Check what you actually run with `SELECT version();` and state that version in the final report. Pinning to `postgres:16` needs internet to pull the image, and an existing volume created by a newer version must be removed first (`docker compose down -v`, which wipes data; reseed afterwards).
8. **`sp_confirm_booking` on an expired hold** marks the booking EXPIRED and then raises an error. The backend's rollback undoes that status change. This is harmless because `sp_expire_holds` and the sweep inside `sp_create_booking` expire it later.

---

## 6. What Phase 3 should do next

1. Express + `pg` project, JWT + bcrypt, role middleware (customer / manager / admin).
2. One shared error handler using the table in 4.3.
3. Endpoints from the table in 4.1 and 4.4, then manager APIs (insert into `MOVIE_SHOW` and `SHOW_PRICE`, show `23P01` as "screen busy") and admin CRUD.
4. Test every endpoint in Postman against the seeded database.
5. Done when: all endpoints work on the seeded data and a simulated payment failure rolls back and is recorded as FAILED.

## 7. Where to read more

- `VIVA_PREP_PHASE2.md`: why each design choice was made, plus a Q&A bank.
- `W3_TEST_REPORT_SECTION.md`: the test log written up for the final report.
- `PLAIN_ENGLISH_GUIDE.md`: the seed script, views and tests explained simply.
