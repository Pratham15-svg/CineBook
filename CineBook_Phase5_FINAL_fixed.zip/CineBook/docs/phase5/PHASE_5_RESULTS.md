# CineBook — Phase 5: Integration, Performance & Deployment — Final Results

**Status: functionally complete and verified, with one honest exception noted below.**

This replaces the "pending" placeholders from the first draft of this document with real results, actually run. Where something still genuinely needs a different machine to finish, that is stated plainly rather than guessed at.

---

## 1. Integration tests — run, passed

```
cd backend && node tests/integration_test.mjs
```

**Real output:**
```
PASS  Register creates a customer account
PASS  Login returns a token
PASS  Second customer can authenticate
PASS  Shows list loads with seeded data
PASS  City filter returns only Hyderabad
PASS  Seat map loads with at least one available seat
PASS  Hold seats creates a booking
PASS  Seat changes to HELD
PASS  Another customer cannot access booking
PASS  NEW: overlapping seat hold is rejected
PASS  Confirm payment succeeds
PASS  Booking appears in My Bookings
PASS  Cancel booking succeeds
PASS  Seat becomes AVAILABLE after cancellation
PASS  Customer is blocked from admin routes
PASS  NEW: customer is blocked from manager routes
PASS  NEW: invalid show ID is rejected
PASS  NEW: duplicate email registration is rejected

18 passed, 0 failed
```

## 2. Query plans — run, real numbers

```
psql -d cinebook -c "EXPLAIN (ANALYZE, BUFFERS) SELECT * FROM v_show_search WHERE start_time > NOW() AND city_name ILIKE '%Mumbai%';"
psql -d cinebook -c "EXPLAIN (ANALYZE, BUFFERS) SELECT * FROM fn_seat_map(1);"
```

| Query | Execution time | Observation |
|---|---|---|
| Movie search by city | **5.1 ms** | Index scans throughout; no sequential scan on large tables |
| Seat map | **0.95 ms** | Uses the partial unique seat index; sub-millisecond |

## 3. Load tests: connection pool before / after — run, real numbers

Same machine, same seeded database, same request count (300 requests, concurrency 20), both runs.

| Endpoint | Pool max | Throughput (req/s) | Average (ms) | p95 (ms) | Errors |
|---|---:|---:|---:|---:|---:|
| `/shows` | 10 | **94.7-95.8** | ~203 | ~300 | 0 |
| `/shows` | 20 | **56.6** | 342 | 481 | 0 |
| `/shows/1/seats` | 10 | **218.6** | 85.5 | 197.5 | 0 |
| `/shows/1/seats` | 20 | **214.5** | 87.6 | 269.1 | 0 |

**Interpretation - and this is the actually interesting result, not a failure:** a bigger pool made the heavier query *slower*, not faster, and left the lighter query about the same. This matches the caveat already written into the original plan ("a larger pool is a hypothesis to test, not a guaranteed speedup") almost exactly. The likely cause here is that the test machine has very few CPU cores, so more concurrent database connections create more contention for the same limited CPU rather than more real parallelism.

**This specific numeric result should not be taken as universal** - it was measured on a shared, resource-constrained sandbox, not dedicated hardware. The right thing to write in the final report is the *finding* (pool size is not a free win; it needs to be tuned against the actual deployment hardware, not maximised blindly) rather than "pool=10 is correct," since a machine with more cores could show the opposite direction. The methodology and the test scripts are solid and reusable regardless of which machine runs them.

## 4. Docker - partially verified, with the gap stated honestly

What was actually confirmed, for real, on an installed Docker engine:
- **The Docker daemon runs successfully.**
- **`docker compose config` parses the compose file with zero errors** - every service, environment variable, volume mount, port mapping, and `depends_on`/healthcheck wiring resolves correctly. This catches the most common class of real-world Compose bugs (YAML typos, bad variable references, wrong service names) and all of that is clean.
- The three Dockerfiles (`backend/Dockerfile`, `frontend/Dockerfile`, `db/seed/Dockerfile`) and `frontend/nginx.conf` were read in full and are each structurally correct and consistent with the rest of the project.

**What could not be verified:** actually building the images and running `docker compose up` end to end. The environment this was tested in has no route to Docker Hub (the registry that `node:22-alpine`, `postgres:16-alpine`, `nginx:1.27-alpine`, and `python:3.12-slim` are pulled from) - that network path is blocked at the infrastructure level, not something fixable from inside the project. **Whoever has a normal computer with Docker Desktop (or Docker Engine on Linux) needs to run the following once, for the final, true confirmation:**

```bash
cp .env.example .env
docker compose up --build -d
docker compose run --rm seed
docker compose ps
```
Then open `http://localhost:8080`, log in as `customer1@cinebook.test` / `Password@123`, and complete one real booking. If anything fails at that point, it's a real, previously-undiscovered issue worth fixing - everything short of that step has already been checked as carefully as this environment allows.

## 5. Fixed since the first draft
- `db/setup.sh` was missing from the project (needed for manual, non-Docker database setup). Restored and verified: running it against a brand-new, empty database correctly creates the full schema with no errors.

## 6. Summary for the report
Phase 5 delivers: a working integration test suite (18 real scenarios, all passing against the live stack), real query performance numbers, a real performance experiment with an honestly-reported non-obvious result, and a Docker Compose setup that is structurally verified but needs one final run on real hardware to close out completely. That last step is a 10-minute task for anyone with Docker installed - everything it depends on has already been checked.
