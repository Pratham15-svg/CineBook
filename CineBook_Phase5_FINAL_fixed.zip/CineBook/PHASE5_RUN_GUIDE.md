# CineBook Phase 5 — run guide

Requirements: Docker Desktop with Compose; optionally Node.js 22+ for local test scripts.

1. Copy `.env.example` to `.env` and set a unique `JWT_SECRET`.
2. Run `docker compose up --build -d` from this directory.
3. Run `docker compose run --rm seed` once to insert demo data.
4. Visit http://localhost:8080 and log in as `customer1@cinebook.test` / `Password@123`.
5. Run the integration and load tests on the host from `backend/` using Node.js 22+:
   - `node tests/integration_test.mjs`
   - `node tests/load_test.mjs /shows 20 300`
   - `node tests/load_test.mjs /shows/1/seats 20 300`
6. Follow `docs/phase5/PHASE_5_RESULTS.md` for SQL query plans and pool size A/B measurements.

**Note:** Docker and PostgreSQL tests have not been executed in the authoring environment. Verify before submitting. For a clean reset, `docker compose down -v` **deletes the database**; only do this if you want to discard all local data.
